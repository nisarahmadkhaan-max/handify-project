import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

export interface Request {
  _id: string;
  category: string;
  service: string;
  estimatedCost: number;
  date: string;
  time: string;
  location: string;
  additionalInstructions: string;
  status: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
  __v: number;
}

@Injectable({
  providedIn: 'root'
})
export class RequestService {
  private apiUrl = 'https://public-repo-j9sl.onrender.com/api'; // Adjust port if needed
  private refreshSubject = new Subject<void>();

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
    const token = currentUser?.token || '';
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  getRequests(): Observable<Request[]> {
    return this.http.get<Request[]>(`${this.apiUrl}/requests`);
  }

  getMyRequests(): Observable<Request[]> {
    return this.http.get<Request[]>(`${this.apiUrl}/my-requests`, { headers: this.getHeaders() });
  }

  getRequestById(id: string): Observable<Request> {
    return this.http.get<Request>(`${this.apiUrl}/requests/${id}`);
  }

  refreshRequests() {
    this.refreshSubject.next();
  }

  onRefresh(): Observable<void> {
    return this.refreshSubject.asObservable();
  }
} 