import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  // private apiUrl = 'https://711b-175-107-215-25.ngrok-free.app/api'; // Update this with your backend URL 
  private apiUrl = 'https://public-repo-j9sl.onrender.com/api'; // Update this with your backend URL

  constructor(private http: HttpClient) { }

  // Get all services
  getAllServices(): Observable<any> {
    return this.http.get(`${this.apiUrl}/services`);
  }

  // Get services by category
  getServicesByCategory(category: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/services/category/${category}`);
  }

  // Get notifications for a user
  getNotifications(userId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/notifications?userId=${userId}`);
  }

  // Submit a contact support request
  submitContactSupportRequest(data: { subject: string; message: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/contact-support`, data);
  }
} 