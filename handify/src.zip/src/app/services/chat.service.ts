import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ChatMessage {
  _id?: string;
  userId: string;
  text: string;
  type: 'text' | 'audio';
  audioLength?: string;
  timestamp?: string;
}

@Injectable({ providedIn: 'root' })
export class ChatService {
  private apiUrl = 'https://public-repo-j9sl.onrender.com/api/chat'; // Adjust if needed

  constructor(private http: HttpClient) {}

  sendMessage(message: ChatMessage): Observable<ChatMessage> {
    return this.http.post<ChatMessage>(`${this.apiUrl}/send`, message);
  }

  getMessages(userId: string): Observable<ChatMessage[]> {
    return this.http.get<ChatMessage[]>(`${this.apiUrl}/messages?userId=${userId}`);
  }
} 