import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;
  // private apiUrl = "https://711b-175-107-215-25.ngrok-free.app/api"
  private apiUrl = "https://public-repo-j9sl.onrender.com/api";

  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser') || 'null'));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue() {
    return this.currentUserSubject.value;
  }

  login(credentials: { phoneNumber: string; password: string }) {
    return this.http.post<any>(`${this.apiUrl}/auth/login`, credentials)
      .pipe(map(response => {
        // store user details and jwt token in local storage
        localStorage.setItem('currentUser', JSON.stringify(response));
        this.currentUserSubject.next(response);
        return response;
      }));
  }

  signup(userData: { fullName: string; email: string; phoneNumber: string; password: string }) {
    return this.http.post<any>(`${this.apiUrl}/auth/signup`, userData)
      .pipe(map(response => {
        // store user details and jwt token in local storage
        localStorage.setItem('currentUser', JSON.stringify(response));
        this.currentUserSubject.next(response);
        return response;
      }));
  }

  forgotPassword(phoneNumber: string) {
    return this.http.post<any>(`${this.apiUrl}/auth/forgot-password`, { phoneNumber });
  }

  resetPassword(data: { phoneNumber: string; otp: string; newPassword: string }) {
    return this.http.post<any>(`${this.apiUrl}/auth/reset-password`, data);
  }

  verifyOtp(data: { email: string; otp: string }) {
    return this.http.post<any>(`${this.apiUrl}/auth/verify-otp`, data)
      .pipe(map(response => {
        localStorage.setItem('currentUser', JSON.stringify(response));
        this.currentUserSubject.next(response);
        return response;
      }));
  }

  logout() {
    // remove user from local storage and set current user to null
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  // New methods to handle login status and onboarding
  async isLoggedIn(): Promise<boolean> {
    const user = this.currentUserValue;
    if (!user) return false;

    // Check if token exists and is not expired
    try {
      const token = user.token;
      if (!token) return false;

      // You could also verify the token with the backend here
      // For now, we'll just check if it exists
      return true;
    } catch {
      return false;
    }
  }

  async hasSeenOnboarding(): Promise<boolean> {
    return localStorage.getItem('hasSeenOnboarding') === 'true';
  }

  async setHasSeenOnboarding(): Promise<void> {
    localStorage.setItem('hasSeenOnboarding', 'true');
  }

  async getUserData() {
    return this.currentUserValue;
  }

  // Add this method to update user data in localStorage and BehaviorSubject
  updateCurrentUser(user: any) {
    const current = this.currentUserValue;
    if (current) {
      const updated = { ...current, user };
      localStorage.setItem('currentUser', JSON.stringify(updated));
      this.currentUserSubject.next(updated);
    }
  }
} 