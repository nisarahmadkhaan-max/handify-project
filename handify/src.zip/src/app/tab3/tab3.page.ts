import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RequestService, Request } from '../services/request.service';
import { AuthService } from '../services/auth.service';
import { TranslationService } from '../services/translation.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-tab3',
  templateUrl: './tab3.page.html',
  styleUrls: ['./tab3.page.scss'],
  standalone: false
})
export class Tab3Page implements OnInit, OnDestroy {
  activeFilter: string = 'All';
  requests: Request[] = [];
  filteredRequests: Request[] = [];
  loading = false;
  error: string | null = null;
  currentUserId: string | null = null;
  currentLang = 'en';
  private refreshSubscription: Subscription;

  constructor(
    public router: Router, 
    private requestService: RequestService, 
    private route: ActivatedRoute,
    private authService: AuthService,
    public translationService: TranslationService
  ) { 
    // Subscribe to refresh events
    this.refreshSubscription = this.requestService.onRefresh().subscribe(() => {
      console.log('Tab3: Refresh event received, fetching requests...');
      this.fetchRequests();
    });
  }

  ngOnInit() {
    this.translationService.currentLang$.subscribe(lang => {
      this.currentLang = lang;
    });
    this.getCurrentUser();
    this.fetchRequests();
  }

  ionViewWillEnter() {
    // This method is called every time the page is about to be displayed
    console.log('Tab3: Page will enter, refreshing data...');
    this.fetchRequests();
  }

  ngOnDestroy() {
    if (this.refreshSubscription) {
      this.refreshSubscription.unsubscribe();
    }
  }

  getCurrentUser() {
    const currentUser = this.authService.currentUserValue;
    if (currentUser && currentUser.user && currentUser.user._id) {
      this.currentUserId = currentUser.user._id;
    } else if (currentUser && currentUser._id) {
      this.currentUserId = currentUser._id;
    }
  }

  fetchRequests() {
    this.loading = true;
    this.error = null;
    this.requestService.getMyRequests().subscribe({
      next: (data) => {
        this.requests = data;
        console.log('My requests:', this.requests);
        
        this.filterRequests(this.activeFilter);
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load requests.';
        this.loading = false;
        console.error('Error fetching requests:', err);
      }
    });
  }

  filterRequests(filter: string) {
    this.activeFilter = filter;
    if (filter === 'All') {
      this.filteredRequests = [...this.requests].sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return dateB.getTime() - dateA.getTime(); // Sort by date descending (newest first)
      });
    } else {
      this.filteredRequests = this.requests.filter(request => 
        request.status.toLowerCase() === filter.toLowerCase()
      ).sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return dateB.getTime() - dateA.getTime(); // Sort by date descending (newest first)
      });
    }
  }

  viewRequestDetails(request: Request) {
    console.log('viewRequestDetails called with:', request);
    this.router.navigateByUrl(`/request-details/${request._id}`);
  }

  getStatusColor(status: string): string {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return 'green';
      case 'pending':
        return 'gold';
      case 'cancelled':
        return 'red';
      case 'completed':
        return 'blue';
      default:
        return 'gray';
    }
  }

  formatDateTime(dateTime: string): string {
    if (!dateTime) return '';
    // Try to parse as ISO or fallback
    const date = new Date(dateTime);
    if (isNaN(date.getTime())) return dateTime; // fallback to raw if invalid
    // Format as 'MMM d, y, h:mm a'
    return date.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }

  // Helper method to get service name from category and service
  getServiceName(request: Request): string {
    return `${request.category} - ${request.service}`;
  }

  // Helper method to get booking ID (using _id)
  getBookingId(request: Request): string {
    return request._id;
  }

  // Helper method to get combined date and time
  getDateTime(request: Request): string {
    const date = new Date(request.date);
    const time = new Date(request.time);
    
    if (isNaN(date.getTime()) || isNaN(time.getTime())) {
      return `${request.date} ${request.time}`;
    }
    
    // Combine date and time
    const combinedDateTime = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 
                                    time.getHours(), time.getMinutes());
    
    return combinedDateTime.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }

  // Helper method to check if user has any requests
  hasRequests(): boolean {
    return this.requests.length > 0;
  }

  // Helper method to check if filtered requests exist
  hasFilteredRequests(): boolean {
    return this.filteredRequests.length > 0;
  }

  switchLanguage(lang: string) {
    this.translationService.setLanguage(lang);
  }
}
