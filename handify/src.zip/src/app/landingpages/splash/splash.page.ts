// home.page.ts
import { Component, ElementRef, ViewChild, AfterViewInit, NgZone } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-splash',
  templateUrl: './splash.page.html',
  styleUrls: ['./splash.page.scss'],
  standalone: false
})
export class SplashPage implements AfterViewInit {
  @ViewChild('swipeTrack') swipeTrack!: ElementRef;
  @ViewChild('swipeThumb') swipeThumb!: ElementRef;

  position: number = 0;
  completed: boolean = false;
  trackHeight: number = 0;
  isDragging: boolean = false;
  startY: number = 0;

  constructor(
    private toastCtrl: ToastController,
    private ngZone: NgZone,
    private router: Router,
    private navCtrl: NavController,
    private storage: Storage,
    private authService: AuthService
  ) {
    this.checkFirstLaunch();
  }

  async checkFirstLaunch() {
    await this.storage.create();
    const isLoggedIn = await this.authService.isLoggedIn();
    const hasSeenOnboarding = await this.authService.hasSeenOnboarding();

    if (isLoggedIn) {
      this.router.navigateByUrl('/tabs/tab1');
    } else if (hasSeenOnboarding) {
      this.router.navigateByUrl('/login');
    }
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.setupSwipe();
    }, 100);
  }

  setupSwipe() {
    const track = this.swipeTrack.nativeElement;
    const thumb = this.swipeThumb.nativeElement;
    
    this.trackHeight = track.offsetHeight;
    console.log(this.trackHeight);
    if(this.trackHeight == 0){
      this.position = this.trackHeight - thumb.offsetHeight + 20; // Start at bottom
    }else{
      this.position = 20
    }

    console.log(this.position);

    const onStart = (e: any) => {
      if (this.completed) return;
      this.isDragging = true;
      this.startY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
      thumb.style.transition = 'none';
      document.addEventListener('mousemove', onMove);
      document.addEventListener('touchmove', onMove);
      document.addEventListener('mouseup', onEnd);
      document.addEventListener('touchend', onEnd);
    };

    const onMove = (e: any) => {
      if (!this.isDragging) return;
      const clientY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
      const deltaY = clientY - this.startY;
      const maxPosition = this.trackHeight - thumb.offsetHeight - 20;
      // Move up: negative deltaY, but clamp between 0 (top) and maxPosition (bottom)
      this.ngZone.run(() => {
        this.position = Math.max(0, Math.min(maxPosition, maxPosition + deltaY));
        console.log(this.position);
        // Calculate how far we've moved from the bottom (in percentage)
        const distanceFromBottom = (this.position / maxPosition) * 100;
        // Complete when we've moved 70% of the way up

        console.log(distanceFromBottom);
        if (distanceFromBottom <= 30) {
          this.completeSwipe();
        }
      });
    };

    const onEnd = () => {
      if (!this.isDragging) return;
      this.isDragging = false;
      thumb.style.transition = 'transform 0.3s ease-out';
      if (!this.completed) {
        this.ngZone.run(() => {
          this.position = this.trackHeight - thumb.offsetHeight - 20;
        });
      }
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('mouseup', onEnd);
      document.removeEventListener('touchend', onEnd);
    };

    thumb.addEventListener('mousedown', onStart);
    thumb.addEventListener('touchstart', onStart);
  }

  completeSwipe() {
    if (this.completed) return;
    this.completed = true;
    this.position = 0;
    // this.showToast();
    this.onSwipeComplete();
  }

  async showToast() {
    const toast = await this.toastCtrl.create({
      message: 'Swipe completed!',
      duration: 1000,
      color: 'success'
    });
    await toast.present();
  }

  onSwipeComplete() {
    console.log("working");
    this.router.navigateByUrl('/onboarding');
  }

  reset() {
    this.completed = false;
    this.position = this.trackHeight - this.swipeThumb.nativeElement.offsetHeight - 20;
    this.isDragging = false;
  }
}
