import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslationService } from '../../services/translation.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
  standalone: false
})
export class SettingsPage implements OnInit {
  settings = {
    notifications: {
      enabled: true,
      serviceUpdates: true,
      promotions: false,
      bookingReminders: true
    },
    location: {
      enabled: true,
      useCurrentLocation: true,
      manualAddress: ''
    }
  };

  // Add state variables for dynamic forms
  showChangePassword = false;
  showLanguagePreferences = false;
  showAboutApp: boolean = false;

  // Change password form fields
  currentPassword: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  passwordChangeMessage: string = '';

  // Language selection
  availableLanguages = [
    { code: 'en', label: 'English' },
    { code: 'ur', label: 'اردو' }
  ];
  selectedLanguage: string = 'en';
  languageChangeMessage: string = '';
  currentLang = 'en';

  constructor(private router: Router, public translationService: TranslationService) { }

  ngOnInit() {
    this.translationService.currentLang$.subscribe(lang => {
      this.currentLang = lang;
    });
  }

  goBack() {
    this.router.navigate(['/my-profile']);
  }

  changePassword() {
    this.showChangePassword = !this.showChangePassword;
    this.showLanguagePreferences = false;
  }

  changeLanguage() {
    this.showLanguagePreferences = !this.showLanguagePreferences;
    this.showChangePassword = false;
  }

  submitPasswordChange() {
    if (!this.currentPassword || !this.newPassword || !this.confirmPassword) {
      this.passwordChangeMessage = 'Please fill in all fields.';
      return;
    }
    if (this.newPassword !== this.confirmPassword) {
      this.passwordChangeMessage = 'New passwords do not match.';
      return;
    }
    // TODO: Integrate with backend
    this.passwordChangeMessage = 'Password changed successfully!';
    this.currentPassword = '';
    this.newPassword = '';
    this.confirmPassword = '';
    setTimeout(() => {
      this.showChangePassword = false;
      this.passwordChangeMessage = '';
    }, 1500);
  }

  submitLanguageChange() {
    // TODO: Integrate with translation service
    this.languageChangeMessage = 'Language changed to ' + this.selectedLanguage;
    setTimeout(() => {
      this.showLanguagePreferences = false;
      this.languageChangeMessage = '';
    }, 1500);
  }

  toggleSetting(category: string, setting: string) {
    // @ts-ignore - Using dynamic property access
    this.settings[category][setting] = !this.settings[category][setting];
    
    // If main notification toggle is turned off, disable all sub-notifications
    if (category === 'notifications' && setting === 'enabled' && !this.settings.notifications.enabled) {
      this.settings.notifications.serviceUpdates = false;
      this.settings.notifications.promotions = false;
      this.settings.notifications.bookingReminders = false;
    }
    
    // If location services are disabled, disable current location
    if (category === 'location' && setting === 'enabled' && !this.settings.location.enabled) {
      this.settings.location.useCurrentLocation = false;
    }
  }

  aboutApp() {
    this.showAboutApp = !this.showAboutApp;
  }

  sendFeedback() {
    // Navigate to feedback form
    alert('Feedback form would open here');
  }

  contactSupport() {
    this.router.navigate(['/contact-support']);
  }

  switchLanguage(lang: string) {
    this.translationService.setLanguage(lang);
  }
}