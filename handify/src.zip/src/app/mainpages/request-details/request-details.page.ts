import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RequestService, Request } from '../../services/request.service';
import { TranslationService } from '../../services/translation.service';

@Component({
  selector: 'app-request-details',
  templateUrl: './request-details.page.html',
  styleUrls: ['./request-details.page.scss'],
  standalone: false
})
export class RequestDetailsPage implements OnInit {
  requestId: string = '';
  requestDetails?: Request;
  loading = false;
  error: string | null = null;
  currentLang = 'en';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private requestService: RequestService,
    public translationService: TranslationService
  ) { }

  ngOnInit() {
    this.translationService.currentLang$.subscribe(lang => {
      this.currentLang = lang;
    });
    this.requestId = this.route.snapshot.paramMap.get('id') || '';
    if (this.requestId) {
      this.loading = true;
      this.requestService.getRequestById(this.requestId).subscribe({
        next: (details) => {
          this.requestDetails = details;
          this.loading = false;
        },
        error: (err) => {
          this.error = 'Failed to load request details.';
          this.loading = false;
        }
      });
    } else {
      this.error = 'No request ID provided.';
    }
  }

  closeDetails() {
    this.router.navigate(['/tabs/tab3']);
  }

  callTechnician() {
    // Since we don't have contact info in the new structure, we'll show a message
    console.log('Contact information not available in current data structure');
  }

  // Helper method to get service name from category and service
  getServiceName(request: Request): string {
    return `${request.category} - ${request.service}`;
  }

  // Helper method to get booking ID (using _id)
  getBookingId(request: Request): string {
    return request._id;
  }

  // Helper method to get combined date and time
  getDateTime(request: Request): string {
    const date = new Date(request.date);
    const time = new Date(request.time);
    
    if (isNaN(date.getTime()) || isNaN(time.getTime())) {
      return `${request.date} ${request.time}`;
    }
    
    // Combine date and time
    const combinedDateTime = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 
                                    time.getHours(), time.getMinutes());
    
    return combinedDateTime.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }

  // Helper method to get status color
  getStatusColor(status: string): string {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return 'green';
      case 'pending':
        return 'gold';
      case 'cancelled':
        return 'red';
      case 'completed':
        return 'blue';
      default:
        return 'gray';
    }
  }

  // Helper method to format estimated cost
  getEstimatedCost(request: Request): string {
    return `$${request.estimatedCost}`;
  }

  // Helper method to get created date
  getCreatedDate(request: Request): string {
    const date = new Date(request.createdAt);
    if (isNaN(date.getTime())) return request.createdAt;
    
    return date.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }

  switchLanguage(lang: string) {
    this.translationService.setLanguage(lang);
  }
}
