import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ChatService, ChatMessage } from '../../services/chat.service';
import { TranslationService } from '../../services/translation.service';

@Component({
  selector: 'app-live-chat',
  templateUrl: './live-chat.page.html',
  styleUrls: ['./live-chat.page.scss'],
  standalone: false
})
export class LiveChatPage implements OnInit {
  messages: ChatMessage[] = [];
  newMessage: string = '';
  showWelcomeMessage: boolean = true;
  userId: string = 'USER_ID'; // TODO: Replace with actual user ID logic
  currentLang = 'en';

  constructor(private router: Router, private chatService: ChatService, public translationService: TranslationService) { }

  ngOnInit() {
    this.translationService.currentLang$.subscribe(lang => {
      this.currentLang = lang;
    });
    this.loadMessages();
  }

  loadMessages() {
    this.chatService.getMessages(this.userId).subscribe(messages => {
      this.messages = messages;
      this.showWelcomeMessage = messages.length === 0;
    });
  }

  sendMessage() {
    if (!this.newMessage.trim()) return;

    const message: ChatMessage = {
      userId: this.userId,
      text: this.newMessage,
      type: 'text'
    };

    this.chatService.sendMessage(message).subscribe(sentMessage => {
      this.messages.push(sentMessage);
      this.newMessage = '';
      this.showWelcomeMessage = false;
    });
  }

  sendAudio() {
    const message: ChatMessage = {
      userId: this.userId,
      text: '',
      type: 'audio',
      audioLength: '0:05'
    };
    this.chatService.sendMessage(message).subscribe(sentMessage => {
      this.messages.push(sentMessage);
      this.showWelcomeMessage = false;
    });
  }

  sendImage() {
    alert('Image selection would open here');
  }

  goBack() {
    this.router.navigate(['/home']);
  }

  switchLanguage(lang: string) {
    this.translationService.setLanguage(lang);
  }
}
