import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ApiService } from '../../services/api.service';
import { TranslationService } from '../../services/translation.service';
import { Router, ActivatedRoute } from '@angular/router';

interface Service {
  _id: string;
  name: string;
  description: string;
  imageUrl: string;
  category: string;
  price: number;
}

@Component({
  selector: 'app-servicepage',
  templateUrl: './servicepage.page.html',
  styleUrls: ['./servicepage.page.scss'],
  standalone: false
})
export class ServicepagePage implements OnInit {
  services: Service[] = [];
  filteredServices: Service[] = [];
  loading: boolean = true;
  error: string = '';
  showSearchBar: boolean = false;
  searchTerm: string = '';
  selectedCategory: any = null;
  currentLang = 'en';

  constructor(
    private navCtrl: NavController,
    private apiService: ApiService,
    private router: Router,
    private route: ActivatedRoute,
    public translationService: TranslationService
  ) { }

  ngOnInit() {
    this.translationService.currentLang$.subscribe(lang => {
      this.currentLang = lang;
    });
    this.route.queryParams.subscribe(params => {
      if (params['categoryId'] && params['categoryName']) {
        this.selectedCategory = {
          id: params['categoryId'],
          name: params['categoryName'],
          image: params['categoryImage']
        };
        this.loadServices();
      } else {
        // Fallback to default category if no category is selected
        this.selectedCategory = {
          id: 'plumbing',
          name: 'Plumbing',
          image: ''
        };
        this.loadServices();
      }
    });
  }

  toggleSearchBar() {
    this.showSearchBar = !this.showSearchBar;
    if (!this.showSearchBar) {
      this.searchTerm = '';
      this.filteredServices = [...this.services];
    }
  }

  onSearchChange(event: any) {
    const value = event.detail.value.toLowerCase();
    this.filteredServices = this.services.filter(service =>
      service.name.toLowerCase().includes(value) ||
      service.description.toLowerCase().includes(value)
    );
  }

  loadServices() {
    this.loading = true;
    const categoryName = this.selectedCategory?.name || 'Plumbing';
    this.apiService.getServicesByCategory(categoryName).subscribe({
      next: (data) => {
        this.services = data;
        this.filteredServices = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load services. Please try again later.';
        this.loading = false;
        console.error('Error loading services:', err);
      }
    });
  }

  bookservice(service: Service) {
    // Pass the service data to the booking page as a query param
    this.router.navigate(['/bookservice'], {
      queryParams: { service: JSON.stringify(service) }
    });
  }

  goBack() {
    this.router.navigate(['/tabs/tab2']);
  }

  switchLanguage(lang: string) {
    this.translationService.setLanguage(lang);
  }
}

