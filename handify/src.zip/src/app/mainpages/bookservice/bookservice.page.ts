import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from '../../services/booking.service';
import { TranslationService } from '../../services/translation.service';
import { ToastController, PopoverController } from '@ionic/angular';
import { Geolocation } from '@capacitor/geolocation';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { DatetimePickerComponent } from './datetime-picker.component';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-bookservice',
  templateUrl: './bookservice.page.html',
  styleUrls: ['./bookservice.page.scss'],
  standalone: false
})
export class BookservicePage implements OnInit {
  bookingData = {
    category: '',
    service: '', // will be set to service _id
    estimatedCost: 0,
    date: '',
    time: '',
    location: '',
    additionalInstructions: ''
  };

  minDate: string;
  maxDate: string;
  selectedDate: string = '';
  selectedTime: string = '';
  selectedService: any = null; // new property
  currentLang = 'en';

  constructor(
    private router: Router,
    private route: ActivatedRoute, // <-- Added
    private bookingService: BookingService,
    private toastController: ToastController,
    private http: HttpClient,
    private popoverController: PopoverController,
    public translationService: TranslationService
  ) {
    // Set minimum date to today
    this.minDate = new Date().toISOString();
    // Set maximum date to 1 year from today
    const maxDate = new Date();
    maxDate.setFullYear(maxDate.getFullYear() + 1);
    this.maxDate = maxDate.toISOString();
  }

  ngOnInit() {
    this.translationService.currentLang$.subscribe(lang => {
      this.currentLang = lang;
    });
    this.route.queryParams.subscribe(params => {
      if (params['service']) {
        try {
          this.selectedService = JSON.parse(params['service']);
          this.bookingData.service = this.selectedService._id;
          this.bookingData.category = this.selectedService.category || '';
          this.bookingData.estimatedCost = this.selectedService.price || 0;
        } catch {
          this.selectedService = params['service'];
          this.bookingData.service = params['service'];
        }
      }
    });
  }

  async getCurrentLocation() {
    try {
      const coordinates = await Geolocation.getCurrentPosition();
      const lat = coordinates.coords.latitude;
      const lng = coordinates.coords.longitude;
      
      // Convert coordinates to address using Google Maps Geocoding API
      const apiKey = environment.googleMapsApiKey;
      const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;
      
      this.http.get(url).subscribe(async (response: any) => {
        if (response.results && response.results.length > 0) {
          const address = response.results[0].formatted_address;
          this.updateLocation(address);
          
          const toast = await this.toastController.create({
            message: 'Location updated successfully!',
            duration: 2000,
            color: 'success'
          });
          toast.present();
        }
      }, async (error) => {
        console.error('Geocoding error:', error);
        const toast = await this.toastController.create({
          message: 'Error getting address. Please try again.',
          duration: 2000,
          color: 'danger'
        });
        toast.present();
      });
    } catch (error) {
      console.error('Geolocation error:', error);
      const toast = await this.toastController.create({
        message: 'Error getting location. Please try again.',
        duration: 2000,
        color: 'danger'
      });
      toast.present();
    }
  }

  async confirmBooking() {
    // Validate required fields
    console.log(this.bookingData)
    if (!this.bookingData.category || !this.bookingData.service || !this.bookingData.date || 
        !this.bookingData.time || !this.bookingData.location) {
      const toast = await this.toastController.create({
        message: 'Please fill in all required fields',
        duration: 2000,
        color: 'danger'
      });
      toast.present();
      return;
    }

    try {
      const response = await this.bookingService.createBooking(this.bookingData).toPromise();
      if (response.success) {
        const toast = await this.toastController.create({
          message: 'Booking confirmed successfully!',
          duration: 2000,
          color: 'success'
        });
        toast.present();
        
        // Navigate to confirmation page with booking data
        this.router.navigate(['/bookingconfirm'], {
          queryParams: {
            bookingData: JSON.stringify(response.data)
          }
        });
      }
    } catch (error: any) {
      console.error('Booking error:', error);
      let message = 'Error creating booking. Please try again.';
      
      if (error.error?.message === 'Please authenticate.') {
        message = 'Your session has expired. Please login again.';
        // Redirect to login page
        this.router.navigate(['/login']);
      }
      
      const toast = await this.toastController.create({
        message: message,
        duration: 2000,
        color: 'danger'
      });
      toast.present();
    }
  }

  async openDatePicker() {
    const popover = await this.popoverController.create({
      component: DatetimePickerComponent,
      componentProps: {
        presentation: 'date',
        min: this.minDate,
        max: this.maxDate
      },
      cssClass: 'date-time-popover'
    });

    await popover.present();

    const { data } = await popover.onDidDismiss();
    if (data) {
      this.selectedDate = data;
      this.bookingData.date = data;
    }
  }

  async openTimePicker() {
    const popover = await this.popoverController.create({
      component: DatetimePickerComponent,
      componentProps: {
        presentation: 'time',
        hourCycle: 'h23'
      },
      cssClass: 'date-time-popover'
    });

    await popover.present();

    const { data } = await popover.onDidDismiss();
    if (data) {
      this.selectedTime = data;
      this.bookingData.time = data;
    }
  }

  // Helper methods to update booking data
  updateCategory(category: string) {
    this.bookingData.category = category;
  }

  updateService(service: string) {
    this.bookingData.service = service;
  }

  updateDate(date: string | string[] | null | undefined) {
    if (date) {
      this.selectedDate = Array.isArray(date) ? date[0] : date;
      this.bookingData.date = this.selectedDate;
    }
  }

  updateTime(value: string | string[] | null | undefined) {
    if (value) {
      this.selectedTime = Array.isArray(value) ? value[0] : value;
      this.bookingData.time = this.selectedTime;
    }
  }

  updateLocation(location: string | null | undefined) {
    console.log('Updating location:', location);
    this.bookingData.location = location || '';
  }

  updateInstructions(instructions: string | null | undefined) {
    this.bookingData.additionalInstructions = instructions || '';
  }

  switchLanguage(lang: string) {
    this.translationService.setLanguage(lang);
  }
}