import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { TranslationService } from '../services/translation.service';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
  standalone: false
})
export class Tab4Page implements OnInit {
  userProfile = {
    name: 'John Doe',
    tagline: 'Local Connect Member',
    email: 'custom@gmail.com',
    phone: '123-456-7890',
    location: 'C#4 rukun-ud-din square sharifabad fb block 1 karachi'
  };
  
  appVersion = '1.0';
  currentLang = 'en';

  constructor(private router: Router, private authService: AuthService, public translationService: TranslationService) { }

  ngOnInit() {
    this.translationService.currentLang$.subscribe(lang => {
      this.currentLang = lang;
    });
    const userData = this.authService.currentUserValue?.user;
    console.log('User Data on Init:', userData);
    if (userData) {
      this.userProfile = {
        name: userData.fullName || '',
        tagline: 'Handify Member',
        email: userData.email || '',
        phone: userData.phoneNumber || '',
        location: userData.location || ''
      };
    }
  }

  ionViewWillEnter() {
    const userData = this.authService.currentUserValue?.user;
    if (userData) {
      this.userProfile = {
        name: userData.fullName || '',
        tagline: 'handify Member',
        email: userData.email || '',
        phone: userData.phoneNumber || '',
        location: userData.location || ''
      };
    }
  }

  closeProfile() {
    this.router.navigate(['/tabs/tab1']);
  }

  editProfile() {
    this.router.navigate(['tabs/tab4/edit-profile']);
  }

  navigateTo(route: string) {
    this.router.navigate([`/${route}`]);
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  openTerms() {
    // Open terms of service
    alert('Terms of Service would open here');
  }

  openPrivacy() {
    // Open privacy policy
    alert('Privacy Policy would open here');
  }

  switchLanguage(lang: string) {
    this.translationService.setLanguage(lang);
  }
}