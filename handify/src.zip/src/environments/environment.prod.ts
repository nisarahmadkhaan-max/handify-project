export const environment = {
  production: true,
  apiUrl: 'https://public-repo-j9sl.onrender.com//api',
  googleMapsApiKey: 'YOUR_GOOGLE_MAPS_API_KEY'
};
